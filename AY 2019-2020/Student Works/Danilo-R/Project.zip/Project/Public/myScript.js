// Variables used in the project

// an array of cards (sequenced by the name of the class)
var cardsArray = document.getElementsByClassName('cards');
// boolean variable, 
var anyCardClicked = false;
// boolean variable, checks used if the picked pair is not matched 
var timeToWait = false;
// boolean varaible, checks if the user has selected dark theme
var darkTheme = false;
// variables representing the selecting card (initially set to empty)
var firstCard;
var secondCard;
// value of matched pairs
var pairs = 0;
// moves counter
var moves = 0;
// score counter
var score = 0;
// value of average moves per matched pair (number of moves / 10)
var averageMoves = 0;
// value of average seconds per matched pair (number of seconds / 10)
var averageSeconds = 0;
// value of accuracy in solving the memory game (15 or less moves equals 100% accuracy, each move about 15 decreases the accuracy by 2.5%)
var accuracyValue = 0;
var condition = 0;
// seconds (used in timer)
var seconds = 0;
// minutes (increases by 1 when seconds equals to 60. After that, seconds reset to 0)
var minutes = 0;
var timeToStart = false;
var startTimer = setInterval(timer, 1000);
// test -------
var highest = 0;

// Sound effects
var click = new Audio("Static/Sound-Effects/click.mp3");
var correct = new Audio("Static/Sound-Effects/correct.mp3");
var incorrect = new Audio("Static/Sound-Effects/incorrect.mp3");

shuffleCards();
startAndStopTimer();

// main function 
function showCard() {
	showScorePanel();
	// if cards are not matched, end the function
	if (timeToWait == true) {
		return;
	}
	// in case the user clicks the same card twice, end the function
	if (this == firstCard) {
		return;
	}
	this.classList.add("show");
	if (anyCardClicked == false) {
		firstCard = this;
		// card has been clicked, play 'click' sound effect
		click.play();
		anyCardClicked = true;
		return;
	} else {
		secondCard = this;
		anyCardClicked = false;
		// checks if the datasets of the selected cards are equal
		if (firstCard.dataset.monument == secondCard.dataset.monument) {
			// cards have been matched, make the front of the card stay visible 
			firstCard.removeEventListener('click', showCard);
			secondCard.removeEventListener('click', showCard);
			// pairs are matched, play 'correct' sound effect
			correct.play();
			// condition for bonus points increases by 1
			condition++;
			// checks if the condition is equal to 3
			if (condition == 3) {
				// user has matched the pair 3 times in a row (+200 points)
				score = score + 200;
				// sets condition to 0
				condition = 0;
			}
			// increase number of moves
			movesMade();
			startValue();
			// increase number of matched pairs
			pairMatched();
		} else {
			// pairs are not matched, play 'incorrect' sound effect
			incorrect.play();
			// no function evoking is available while time to wait is true. Meanwhile, user gets 1 second to remember the cards before they are turned back
			timeToWait = true;
			setTimeout(notPairOfCards, 1000);
			// increase number of moves
			movesMade();
			condition = 0;
		}
	}
}

// cards are not matched, turn them back 
function notPairOfCards() {
	firstCard.classList.remove('show');
	secondCard.classList.remove('show');
	// time to wait is false, function can be evoked again
	timeToWait = false;
	startValue();
}

// the initial values of variables
function startValue() {
	anyCardClicked = false;
	timeToWait = false;
	firstCard = null;
	secondCard = null;
}

// shuffle the index of the card in an array
function shuffleCards() {
	// 'i' equals to the number of cards in an array
	for (var i = 0; i < cardsArray.length; i++) {
		// get random value and set the index of the card to it
		var position = Math.floor(Math.random() * 12);
		cardsArray[i].style.order = position;
	}
}

// add an event listener to each card
for (var i = 0; i < cardsArray.length; i++) {
	cardsArray[i].addEventListener('click', showCard);
}

// show score panel (after the first card has been clicked)
function showScorePanel() {
	var scorePanel = document.getElementsByClassName('score-panel');
	for (var i = 0; i < scorePanel.length; i++) {
		scorePanel[i].style.visibility = 'visible';
	}
	// visible when the user starts playing the game
	document.getElementById('theme-mode').style.visibility = 'visible';
	document.getElementById('top-part-header').style.visibility = 'hidden';
	document.getElementById('top-part-paragraph').style.display = 'none';
	document.getElementById('bottom-part-paragraph').style.visibility = 'hidden';
}

// list of tasks to do if pairs are matched
function pairMatched() {
	var x = document.getElementById('pairs');
	var y = document.getElementById('score');
	var z = document.getElementById('final-score');
	var message = document.getElementById('message');
	var panel = document.getElementsByClassName('game-completed');
	var movesPerPair = document.getElementById('moves-per-pair');
	var accuracy = document.getElementById('accuracy');
	// pairs are matched, increase the counter of matched pairs
	pairs++;
	// update the display to the user
	x.innerHTML = pairs + " / 10";
	// while moves are less than 20, the user will get +300 points per matched pair
	if (moves <= 20) {
		score = score + 300;
		// show specific message
		message.innerHTML = "Your score has reached the peak!";
		// while moves are greater than 20 but less than 25, the user will get +200 points per matched pair
	} else if (moves > 20 && moves <= 25) {
		score = score + 200;
		// show specific message
		message.innerHTML = "Your score is pretty impressive.";
		// while moves are greater than 25, the user will get +100 points per matched pair
	} else {
		score = score + 100;
		// show specific message
		message.innerHTML = "It's quite a good score."
	}
	// calculate the average number of moves per matched pair
	averageMoves = moves / 10;
	// update the display to the user (rounded up to 1 decimal)
	document.getElementById('moves-per-pair').innerHTML = averageMoves.toFixed(1);
	// if the user matches all pairs of cards in 15 moves or less, accuracy equals to 100%
	if (moves <= 15) {
		accuracyValue = 100;
		// if the user matches all pairs of cards in 35 moves or more, accuracy equals to 50%
	} else if (moves >= 35) {
		accuracyValue = 50;
		// for every move greater than 15, the accuracy decreases by 2.5%
	} else {
		accuracyValue = 100 - ((moves - 15) * 2.5); 
	}
	// update the display to the user
	document.getElementById('accuracy').innerHTML = accuracyValue + "%";
	// calculate the average seconds per matched pair
	averageSeconds = ((minutes * 60) + seconds) / 10;
	// update the display to the user (rounded up to 1 decimal)
	document.getElementById('seconds-per-pair').innerHTML = averageSeconds.toFixed(1);
	y.innerHTML = "Score: " + score;
	// if the user matched all pairs of cards, stop the timer show the game status
	if (pairs == 10) {
		timeToStart = false;
		showGameStatus();
		z.innerHTML = score;
	}
}

function movesMade() {
	var x = document.getElementById('moves');
	var y = document.getElementById('score');
	// increment the number of moves 
	moves++;
	x.innerHTML = "Moves: " + moves;
	// if user has selected a pair of cards, start the timer
	if (moves == 1) {
		timeToStart = true;
	}
}

// toggle between light and dark mode
function themeMode() {
	// all tags that need to be changed
	var x = document.body;
	var y = document.getElementsByClassName('score-panel');
	var z = document.getElementById('board');
	var display = document.getElementById('theme-mode');
	var endGame = document.getElementsByClassName('game-completed');
	var score = document.getElementById('final-score');
	var playAgain = document.getElementById('play-again');
	var viewStats = document.getElementById('view-stats');
	var goBack = document.getElementById('go-back');
	var statsPanel = document.getElementById('stats-panel');
	var statsDescription = document.getElementsByClassName('stats-description');

	// the user has selected dark mode, update the display
	if (darkTheme == false) {
		for (var i = 0; i < y.length; i++) {
			y[i].style.color = '#bb86fc';
			y[i].style.transitionDuration = '0.5s';
		}
		for (var i = 0; i < endGame.length; i++) {
			endGame[i].style.backgroundColor = '#212121';
			endGame[i].style.color = '#ffffff';
			endGame[i].style.border = 'none';
		}
		for (var i = 0; i < statsDescription.length; i++) {
			statsDescription[i].style.color = '#ffffff';
		}
		// update the display
		statsPanel.style.backgroundColor = '#212121';
		statsPanel.style.color = '#ffffff';
		x.style.backgroundColor = '#121212';
		x.style.transitionDuration = '0.5s';
		z.style.backgroundColor = '#424242';
		z.style.transitionDuration = '0.5s';
		display.style.color = '#03dac6';
		display.style.transitionDuration = '0.5s';
		score.style.color = '#ffffff';
		playAgain.style.backgroundColor = '#ffffff';
		playAgain.style.color = '#505050';
		viewStats.style.backgroundColor = '#ffffff';
		viewStats.style.color = '#505050';
		goBack.style.backgroundColor = '#ffffff';
		goBack.style.color = '#505050';
		// update the display status to the selected mode
		display.innerHTML = 'Theme: dark';
		// update the boolean value
		darkTheme = true;
		// the user has selected light mode, update the display
	} else {
		for (var i = 0; i < y.length; i++) {
			y[i].style.color = '#d3af37';
			y[i].style.transitionDuration = '0.5s';
		}
		for (var i = 0; i < endGame.length; i++) {
			endGame[i].style.backgroundColor = '#fefefe';
			endGame[i].style.border = '2px solid #eeeeee';
			endGame[i].style.color = '#737373';
			endGame[i].transitionDuration = '0.5s';
		}
		for (var i = 0; i < statsDescription.length; i++) {
			statsDescription[i].style.color = '#505050';
		}
		statsPanel.style.backgroundColor = '#fefefe';
		statsPanel.style.border = '2px solid #eeeeee';
		statsPanel.style.color = '#737373';
		x.style.backgroundColor = 'white';
		x.style.transitionDuration = '0.5s';
		z.style.backgroundColor = '#efefef';
		z.style.transitionDuration = '0.5s;'
		display.style.color = '#018786';
		display.style.transitionDuration = '0.5s';
		score.style.color = "#505050";
		playAgain.style.backgroundColor = '#505050';
		playAgain.style.color = '#ffffff';
		viewStats.style.backgroundColor = '#505050';
		viewStats.style.color = '#ffffff';
		goBack.style.backgroundColor = '#505050';
		goBack.style.color = '#ffffff';
		// update the display status to the selected mode
		display.innerHTML = 'Theme: light';
		// update the boolean value
		darkTheme = false;
	}
}

// all pairs are matched, show the game status
function showGameStatus() {
	var x = document.getElementsByClassName('game-completed');
	for (var i = 0; i < x.length; i++) {
		x[i].style.visibility = 'visible';
	}
}

// the user wants to see its stats, show the stats panel
function showStatsPanel() {
	var x = document.getElementById('stats-panel');
	x.style.visibility = 'visible';
}

// the user has finished seeing its stats, hide the stats panel
function hideStatsPanel() {
	var x = document.getElementById('stats-panel');
	x.style.visibility = 'hidden';
}

// timer, starts when at least 2 moves have been made
function timer() {
	var x = document.getElementById('time');
	var totalScore = document.getElementById('score');
	var totalTime = (minutes * 60) + seconds;
	if (timeToStart == true) {
		seconds++;
		if (seconds == 60) {
			minutes++;
			seconds = 0;
		}
	}
	// update the display to the user
	x.innerHTML = minutes + "m " + seconds + "s";
}

// check if the timer needs to be started or stopped
function startAndStopTimer() {
	if (timeToStart == true) {
		setInterval(timer, 1000);
	} else if (timeToStart == false) {
		clearInterval(timer);
	}
}

// the user wants to play the game again, set all variables to their initial value
function restartGame() {
	shuffleCards();
	startValue();
	pairs = 0;
	moves = 0;
	score = 0;
	condition = 0;
	seconds = 0;
	minutes = 0;
	var x = document.getElementById('pairs');
	var y = document.getElementById('moves');
	var z = document.getElementById('score');
	var time = document.getElementById('time');
	var panel = document.getElementsByClassName('game-completed');
	for (var i = 0; i < panel.length; i++) {
		panel[i].style.visibility = 'hidden';
	}
	for (var i = 0; i < cardsArray.length; i++) {
		cardsArray[i].classList.remove('show');
		cardsArray[i].addEventListener('click', showCard);
	}
	x.innerHTML = pairs + " / 10";
	y.innerHTML = "Moves: " + moves;
	z.innerHTML = "Score: " + score;
	time.innerHTML = minutes + "m " + seconds + "s";
}