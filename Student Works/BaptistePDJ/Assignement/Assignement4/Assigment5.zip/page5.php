
<html>
<head>
	<title>Submission</title>
</head>
<body style="text-align: center;">
	<h2>Submission is received</h2>
	<br>
	<br><br><br>
	The name of your meme: <?php echo $_POST["memeName"]; ?>
	<br>
	Why your meme is the best : <?php echo $_POST["description"]; ?>
	<br>
	Meme picture : <?php echo $_POST["photo"]; ?>
</body>
</html>