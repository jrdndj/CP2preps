
<html>
<head>
	<title>Submission</title>
</head>
<body style="text-align: center;font-size: 50">
	Welcome <?php echo $_POST["firstname"]; ?>
	Here is your Username : <?php echo $_POST["username"]; ?>
	And your Password : <?php echo $_POST["pword"]; ?>
</body>
</html>
